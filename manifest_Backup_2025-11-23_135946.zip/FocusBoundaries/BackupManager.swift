import Foundation
import SwiftUI

struct BackupData: Codable {
    let appVersion: String
    let backupDate: Date
    let values: [Value]
    let routineItems: [RoutineItem]
    let tasks: [Task]
    let history: [HistoryEntry]
}

class BackupManager {
    static let shared = BackupManager()

    private init() {}

    func createBackup(from dataManager: DataManager) -> BackupData {
        return BackupData(
            appVersion: Bundle.main.infoDictionary?["CFBundleShortVersionString"] as? String ?? "1.0",
            backupDate: Date(),
            values: dataManager.values,
            routineItems: dataManager.routineItems,
            tasks: dataManager.tasks,
            history: dataManager.historyEntries
        )
    }

    func exportBackup(from dataManager: DataManager) -> URL? {
        let backup = createBackup(from: dataManager)

        let encoder = JSONEncoder()
        encoder.dateEncodingStrategy = .iso8601
        encoder.outputFormatting = .prettyPrinted

        guard let jsonData = try? encoder.encode(backup) else {
            return nil
        }

        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd_HHmmss"
        let dateString = dateFormatter.string(from: Date())
        let filename = "CupFull_Backup_\(dateString).json"

        let tempURL = FileManager.default.temporaryDirectory.appendingPathComponent(filename)

        do {
            try jsonData.write(to: tempURL)
            return tempURL
        } catch {
            print("Error writing backup file: \(error)")
            return nil
        }
    }

    func importBackup(from url: URL, into dataManager: DataManager) throws {
        let data = try Data(contentsOf: url)

        let decoder = JSONDecoder()
        decoder.dateDecodingStrategy = .iso8601

        let backup = try decoder.decode(BackupData.self, from: data)

        // Restore data to DataManager
        dataManager.values = backup.values
        dataManager.routineItems = backup.routineItems
        dataManager.tasks = backup.tasks
        dataManager.historyEntries = backup.history

        // Save to UserDefaults
        dataManager.saveData()
    }

    func validateBackup(from url: URL) -> Bool {
        do {
            let data = try Data(contentsOf: url)
            let decoder = JSONDecoder()
            decoder.dateDecodingStrategy = .iso8601
            _ = try decoder.decode(BackupData.self, from: data)
            return true
        } catch {
            print("Backup validation error: \(error)")
            return false
        }
    }
}
