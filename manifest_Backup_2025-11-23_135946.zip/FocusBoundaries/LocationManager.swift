import Foundation
import CoreLocation
import Combine

class LocationManager: NSObject, ObservableObject {
    private let locationManager = CLLocationManager()
    private let defaults = UserDefaults.standard

    @Published var authorizationStatus: CLAuthorizationStatus = .notDetermined
    @Published var lastLocation: CLLocation?

    // Keys for UserDefaults
    private let latitudeKey = "cached_latitude"
    private let longitudeKey = "cached_longitude"

    override init() {
        super.init()
        locationManager.delegate = self
        locationManager.desiredAccuracy = kCLLocationAccuracyKilometer
        authorizationStatus = locationManager.authorizationStatus

        // Load cached location
        loadCachedLocation()
    }

    // Request location permission
    func requestPermission() {
        locationManager.requestWhenInUseAuthorization()
    }

    // Request a single location update
    func requestLocation() {
        locationManager.requestLocation()
    }

    // Get current location (cached or live)
    func getCurrentLocation() -> CLLocation? {
        return lastLocation
    }

    // Load cached location from UserDefaults
    private func loadCachedLocation() {
        if let latitude = defaults.value(forKey: latitudeKey) as? Double,
           let longitude = defaults.value(forKey: longitudeKey) as? Double {
            lastLocation = CLLocation(latitude: latitude, longitude: longitude)
        }
    }

    // Save location to UserDefaults for offline use
    private func cacheLocation(_ location: CLLocation) {
        defaults.set(location.coordinate.latitude, forKey: latitudeKey)
        defaults.set(location.coordinate.longitude, forKey: longitudeKey)
    }
}

// MARK: - CLLocationManagerDelegate
extension LocationManager: CLLocationManagerDelegate {
    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        authorizationStatus = manager.authorizationStatus

        // If authorized, request location
        if authorizationStatus == .authorizedWhenInUse || authorizationStatus == .authorizedAlways {
            requestLocation()
        }
    }

    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let location = locations.last else { return }

        lastLocation = location
        cacheLocation(location)
    }

    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location error: \(error.localizedDescription)")
        // If live location fails, cached location will still be available
    }
}
