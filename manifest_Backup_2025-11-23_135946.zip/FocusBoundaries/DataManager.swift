import Foundation
import SwiftUI

// MARK: - Value with Definition
struct Value: Codable, Identifiable, Hashable {
    let id: UUID
    let name: String
    let definition: String
    var isActive: Bool

    init(id: UUID = UUID(), name: String, definition: String, isActive: Bool = false) {
        self.id = id
        self.name = name
        self.definition = definition
        self.isActive = isActive
    }

    // Computed property for soft, transparent color based on value name
    var color: Color {
        let colors: [Color] = [
            .green, .blue, .red, .purple,
            .orange, .yellow, .pink, .teal
        ]

        // Use hash of name to deterministically assign color
        let hash = abs(name.hashValue)
        let index = hash % colors.count
        return colors[index]
    }
}

// MARK: - Routine Item (Simplified, No Colors)
struct RoutineItem: Codable, Identifiable, Equatable {
    let id: UUID
    var title: String
    var time: String // Display time like "9:00 AM" (DEPRECATED - use startTime/endTime)
    var icon: String // SF Symbol name
    var valueIds: [UUID]
    var notificationEnabled: Bool
    var notificationHour: Int?
    var notificationMinute: Int?
    var order: Int

    // NEW: Timeline view properties
    var startTime: Date?      // Start time (e.g., 6:00 AM)
    var endTime: Date?        // End time (e.g., 7:00 AM)
    var activeDays: [Int]?    // Days of week: 0=Sun, 1=Mon, ... 6=Sat. nil = all days

    init(id: UUID = UUID(), title: String, time: String = "", icon: String = "checkmark.circle", valueIds: [UUID] = [], notificationEnabled: Bool = false, notificationHour: Int? = nil, notificationMinute: Int? = nil, order: Int = 0, startTime: Date? = nil, endTime: Date? = nil, activeDays: [Int]? = nil) {
        self.id = id
        self.title = title
        self.time = time
        self.icon = icon
        self.valueIds = valueIds
        self.notificationEnabled = notificationEnabled
        self.notificationHour = notificationHour
        self.notificationMinute = notificationMinute
        self.order = order
        self.startTime = startTime
        self.endTime = endTime
        self.activeDays = activeDays
    }

    // Helper: Get duration in minutes
    var durationMinutes: Int? {
        guard let start = startTime, let end = endTime else { return nil }
        return Int(end.timeIntervalSince(start) / 60)
    }

    // Helper: Check if routine is active on a specific day (0=Sun, 6=Sat)
    func isActiveOn(weekday: Int) -> Bool {
        guard let days = activeDays else { return true } // nil = all days
        return days.contains(weekday)
    }
}

// MARK: - Reminder
struct Reminder: Codable, Identifiable, Equatable {
    let id: UUID
    var minutesBefore: Int? // nil = at time of event, 0 = at time, 15 = 15 min before, etc.
    var customDate: Date? // For custom absolute time reminders

    init(id: UUID = UUID(), minutesBefore: Int? = nil, customDate: Date? = nil) {
        self.id = id
        self.minutesBefore = minutesBefore
        self.customDate = customDate
    }
}

// MARK: - Task with Gradient Priority
struct Task: Codable, Identifiable, Equatable {
    let id: UUID
    let createdDate: Date
    var title: String
    var dueDate: Date?
    var valueIds: [UUID]
    var isCompleted: Bool
    var completedDate: Date?

    // Appointment properties
    var isAppointment: Bool
    var location: String?

    // Recurring properties
    var isRecurring: Bool
    var recurringFrequency: RecurringFrequency
    var recurringDays: [Int]? // For weekly: 0=Sun, 1=Mon, etc.
    var visibilityWindow: Int? // Days before to show task

    // Reminder properties
    var reminders: [Reminder]

    init(id: UUID = UUID(), title: String, dueDate: Date? = nil, valueIds: [UUID] = [], isAppointment: Bool = false, location: String? = nil, isRecurring: Bool = false, recurringFrequency: RecurringFrequency = .none, recurringDays: [Int]? = nil, visibilityWindow: Int? = nil, reminders: [Reminder] = []) {
        self.id = id
        self.createdDate = Date()
        self.title = title
        self.dueDate = dueDate
        self.valueIds = valueIds
        self.isCompleted = false
        self.completedDate = nil
        self.isAppointment = isAppointment
        self.location = location
        self.isRecurring = isRecurring
        self.recurringFrequency = recurringFrequency
        self.recurringDays = recurringDays
        self.visibilityWindow = visibilityWindow
        self.reminders = reminders
    }

    // Calculate days until due (for gradient color)
    var daysUntilDue: Int? {
        guard let dueDate = dueDate else { return nil }
        let calendar = Calendar.current
        let startOfToday = calendar.startOfDay(for: Date())
        let startOfDue = calendar.startOfDay(for: dueDate)
        return calendar.dateComponents([.day], from: startOfToday, to: startOfDue).day
    }

    var isOverdue: Bool {
        guard let days = daysUntilDue else { return false }
        return days < 0
    }
}

enum RecurringFrequency: String, Codable, CaseIterable {
    case none = "None"
    case daily = "Daily"
    case weekly = "Weekly"
    case monthly = "Monthly"
}

// MARK: - History Entry (for Year→Month→Day view)
struct HistoryEntry: Codable, Identifiable {
    let id: UUID
    let date: Date
    var completedRoutineIds: [UUID]
    var completedTaskIds: [UUID]

    init(id: UUID = UUID(), date: Date, completedRoutineIds: [UUID] = [], completedTaskIds: [UUID] = []) {
        self.id = id
        self.date = date
        self.completedRoutineIds = completedRoutineIds
        self.completedTaskIds = completedTaskIds
    }
}

// MARK: - Quote for Loading Screen
struct Quote: Codable, Identifiable {
    let id: UUID
    let text: String
    let author: String
    let category: String?

    init(text: String, author: String, category: String? = nil) {
        self.id = UUID()
        self.text = text
        self.author = author
        self.category = category
    }
}

// MARK: - Data Manager
class DataManager: ObservableObject {
    @Published var values: [Value] = []
    @Published var routineItems: [RoutineItem] = []
    @Published var tasks: [Task] = []
    @Published var historyEntries: [HistoryEntry] = []
    @Published var quotes: [Quote] = []

    private let valuesSaveKey = "AppValues"
    private let routineSaveKey = "AppRoutine"
    private let tasksSaveKey = "AppTasks"
    private let historySaveKey = "AppHistory"

    // Solar calculator for sunrise/sunset gradients
    let solarCalculator = SolarCalculator()

    init() {
        loadValues()
        loadRoutine()
        migrateRoutineItems() // Fix items with empty activeDays
        loadTasks()
        loadHistory()
        loadQuotes()
    }

    // MARK: - Values
    func loadValues() {
        if let data = UserDefaults.standard.data(forKey: valuesSaveKey),
           let decoded = try? JSONDecoder().decode([Value].self, from: data) {
            values = decoded
        } else {
            // Load comprehensive values library (182 values)
            values = ValuesLibrary.allValues
            saveValues()
        }
    }

    func saveValues() {
        if let encoded = try? JSONEncoder().encode(values) {
            UserDefaults.standard.set(encoded, forKey: valuesSaveKey)
        }
    }

    func toggleValueActive(_ value: Value) {
        if let index = values.firstIndex(where: { $0.id == value.id }) {
            values[index].isActive.toggle()
            saveValues()
        }
    }

    func addCustomValue(name: String, definition: String) {
        let newValue = Value(name: name, definition: definition, isActive: true)
        values.append(newValue)
        saveValues()
    }

    var activeValues: [Value] {
        values.filter { $0.isActive }
    }

    // MARK: - Routine
    func loadRoutine() {
        if let data = UserDefaults.standard.data(forKey: routineSaveKey),
           let decoded = try? JSONDecoder().decode([RoutineItem].self, from: data) {
            routineItems = decoded.sorted { $0.order < $1.order }
        }
    }

    func saveRoutine() {
        if let encoded = try? JSONEncoder().encode(routineItems) {
            UserDefaults.standard.set(encoded, forKey: routineSaveKey)
        }
    }

    func addRoutineItem(_ item: RoutineItem) {
        var newItem = item
        newItem.order = routineItems.count
        routineItems.append(newItem)
        saveRoutine()
    }

    func updateRoutineItem(_ item: RoutineItem) {
        if let index = routineItems.firstIndex(where: { $0.id == item.id }) {
            routineItems[index] = item
            saveRoutine()
        }
    }

    func deleteRoutineItem(_ item: RoutineItem) {
        routineItems.removeAll { $0.id == item.id }
        saveRoutine()
    }

    // Fix routine items with empty activeDays array (should be nil to show on all days)
    func migrateRoutineItems() {
        var needsSave = false
        for index in routineItems.indices {
            if let activeDays = routineItems[index].activeDays, activeDays.isEmpty {
                // Convert empty array to nil (means "all days")
                routineItems[index].activeDays = nil
                needsSave = true
                print("✓ Migrated routine item: \(routineItems[index].title) - now active all days")
            }
        }
        if needsSave {
            saveRoutine()
            print("✓ Migration complete: Fixed \(routineItems.count) routine items")
        }
    }

    // MARK: - Tasks
    func loadTasks() {
        if let data = UserDefaults.standard.data(forKey: tasksSaveKey),
           let decoded = try? JSONDecoder().decode([Task].self, from: data) {
            tasks = decoded
        }
    }

    func saveTasks() {
        if let encoded = try? JSONEncoder().encode(tasks) {
            UserDefaults.standard.set(encoded, forKey: tasksSaveKey)
        }
    }

    func addTask(_ task: Task) {
        tasks.append(task)
        saveTasks()
    }

    func updateTask(_ task: Task) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index] = task
            saveTasks()
        }
    }

    func deleteTask(_ task: Task) {
        tasks.removeAll { $0.id == task.id }
        saveTasks()
    }

    func completeTask(_ task: Task) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            tasks[index].isCompleted = true
            tasks[index].completedDate = Date()

            // Add to today's history
            addCompletedTaskToHistory(taskId: task.id)

            // Handle recurring
            if task.isRecurring {
                generateNextRecurringTask(from: task)
            }

            saveTasks()
        }
    }

    func snoozeTask(_ task: Task, days: Int) {
        if let index = tasks.firstIndex(where: { $0.id == task.id }) {
            if let currentDueDate = tasks[index].dueDate {
                let calendar = Calendar.current
                if let newDueDate = calendar.date(byAdding: .day, value: days, to: currentDueDate) {
                    tasks[index].dueDate = newDueDate
                    saveTasks()
                }
            }
        }
    }

    func generateNextRecurringTask(from task: Task) {
        guard let dueDate = task.dueDate else { return }
        let calendar = Calendar.current
        var nextDue: Date?

        switch task.recurringFrequency {
        case .daily:
            nextDue = calendar.date(byAdding: .day, value: 1, to: dueDate)
        case .weekly:
            nextDue = calendar.date(byAdding: .weekOfYear, value: 1, to: dueDate)
        case .monthly:
            nextDue = calendar.date(byAdding: .month, value: 1, to: dueDate)
        case .none:
            break
        }

        if let nextDue = nextDue {
            let newTask = Task(
                title: task.title,
                dueDate: nextDue,
                valueIds: task.valueIds,
                isAppointment: task.isAppointment,
                location: task.location,
                isRecurring: true,
                recurringFrequency: task.recurringFrequency,
                recurringDays: task.recurringDays,
                visibilityWindow: task.visibilityWindow,
                reminders: task.reminders  // Copy reminders to new instance (iOS behavior)
            )
            addTask(newTask)
        }
    }

    var activeTasks: [Task] {
        tasks.filter { !$0.isCompleted }
            .sorted { task1, task2 in
                // Overdue first, then by due date
                let days1 = task1.daysUntilDue ?? Int.max
                let days2 = task2.daysUntilDue ?? Int.max
                return days1 < days2
            }
    }

    var overdueTasks: [Task] {
        activeTasks.filter { $0.isOverdue }
    }

    var activeNonOverdueTasks: [Task] {
        activeTasks.filter { !$0.isOverdue }
    }

    // MARK: - History
    func loadHistory() {
        if let data = UserDefaults.standard.data(forKey: historySaveKey),
           let decoded = try? JSONDecoder().decode([HistoryEntry].self, from: data) {
            historyEntries = decoded
        }
    }

    func saveHistory() {
        if let encoded = try? JSONEncoder().encode(historyEntries) {
            UserDefaults.standard.set(encoded, forKey: historySaveKey)
        }
    }

    func saveData() {
        saveValues()
        saveRoutine()
        saveTasks()
        saveHistory()
    }

    func getTodayHistoryEntry() -> HistoryEntry {
        let calendar = Calendar.current
        let today = calendar.startOfDay(for: Date())

        if let existing = historyEntries.first(where: { calendar.isDate($0.date, inSameDayAs: today) }) {
            return existing
        } else {
            let newEntry = HistoryEntry(date: today)
            historyEntries.append(newEntry)
            saveHistory()
            return newEntry
        }
    }

    func addCompletedRoutineToHistory(routineId: UUID) {
        var entry = getTodayHistoryEntry()
        if !entry.completedRoutineIds.contains(routineId) {
            entry.completedRoutineIds.append(routineId)
            updateHistoryEntry(entry)
        }
    }

    func addCompletedTaskToHistory(taskId: UUID) {
        var entry = getTodayHistoryEntry()
        if !entry.completedTaskIds.contains(taskId) {
            entry.completedTaskIds.append(taskId)
            updateHistoryEntry(entry)
        }
    }

    func updateHistoryEntry(_ entry: HistoryEntry) {
        if let index = historyEntries.firstIndex(where: { $0.id == entry.id }) {
            historyEntries[index] = entry
            saveHistory()
        }
    }

    func deleteHistoryEntry(_ entry: HistoryEntry) {
        historyEntries.removeAll { $0.id == entry.id }
        saveHistory()
    }

    // MARK: - Quotes
    func loadQuotes() {
        quotes = getDefaultQuotes()
    }

    func randomQuote() -> Quote {
        quotes.randomElement() ?? Quote(text: "What you think, you become. What you feel, you attract. What you imagine, you create.", author: "Buddha")
    }

    private func getDefaultQuotes() -> [Quote] {
        return [
            Quote(text: "What you think, you become. What you feel, you attract. What you imagine, you create.", author: "Buddha", category: "manifestation"),
            Quote(text: "The only way to do great work is to love what you do.", author: "Steve Jobs", category: "purpose"),
            Quote(text: "Be the change you wish to see in the world.", author: "Mahatma Gandhi", category: "action"),
            Quote(text: "What lies behind us and what lies before us are tiny matters compared to what lies within us.", author: "Ralph Waldo Emerson", category: "inner_strength"),
            Quote(text: "The best time to plant a tree was 20 years ago. The second best time is now.", author: "Chinese Proverb", category: "action"),
            Quote(text: "Your task is not to seek for love, but merely to seek and find all the barriers within yourself that you have built against it.", author: "Rumi", category: "love"),
            Quote(text: "The wound is the place where the Light enters you.", author: "Rumi", category: "growth"),
            Quote(text: "Do not dwell in the past, do not dream of the future, concentrate the mind on the present moment.", author: "Buddha", category: "mindfulness"),
            Quote(text: "In the middle of difficulty lies opportunity.", author: "Albert Einstein", category: "resilience"),
            Quote(text: "Life is 10% what happens to you and 90% how you react to it.", author: "Charles R. Swindoll", category: "perspective"),
            Quote(text: "The only impossible journey is the one you never begin.", author: "Tony Robbins", category: "action"),
            Quote(text: "Everything you've ever wanted is on the other side of fear.", author: "George Addair", category: "courage"),
            Quote(text: "Believe you can and you're halfway there.", author: "Theodore Roosevelt", category: "confidence"),
            Quote(text: "The future belongs to those who believe in the beauty of their dreams.", author: "Eleanor Roosevelt", category: "dreams"),
            Quote(text: "You are never too old to set another goal or to dream a new dream.", author: "C.S. Lewis", category: "possibility"),
            Quote(text: "What we think, we become.", author: "Buddha", category: "mindset"),
            Quote(text: "Whether you think you can or you think you can't, you're right.", author: "Henry Ford", category: "mindset"),
            Quote(text: "The only person you are destined to become is the person you decide to be.", author: "Ralph Waldo Emerson", category: "identity"),
            Quote(text: "Act as if what you do makes a difference. It does.", author: "William James", category: "impact"),
            Quote(text: "Success is not final, failure is not fatal: it is the courage to continue that counts.", author: "Winston Churchill", category: "perseverance"),
            Quote(text: "The secret of getting ahead is getting started.", author: "Mark Twain", category: "action"),
            Quote(text: "Don't watch the clock; do what it does. Keep going.", author: "Sam Levenson", category: "persistence"),
            Quote(text: "Everything you can imagine is real.", author: "Pablo Picasso", category: "imagination"),
            Quote(text: "The only limit to our realization of tomorrow will be our doubts of today.", author: "Franklin D. Roosevelt", category: "doubt"),
            Quote(text: "It is during our darkest moments that we must focus to see the light.", author: "Aristotle", category: "hope"),
            Quote(text: "You must be the change you wish to see in the world.", author: "Mahatma Gandhi", category: "transformation"),
            Quote(text: "Happiness is not something ready made. It comes from your own actions.", author: "Dalai Lama", category: "happiness"),
            Quote(text: "The mind is everything. What you think you become.", author: "Buddha", category: "mindset"),
            Quote(text: "Life is what happens when you're busy making other plans.", author: "John Lennon", category: "presence"),
            Quote(text: "The purpose of our lives is to be happy.", author: "Dalai Lama", category: "purpose"),
            Quote(text: "You only live once, but if you do it right, once is enough.", author: "Mae West", category: "living_fully"),
            Quote(text: "In the end, it's not the years in your life that count. It's the life in your years.", author: "Abraham Lincoln", category: "quality_of_life"),
            Quote(text: "Many of life's failures are people who did not realize how close they were to success when they gave up.", author: "Thomas Edison", category: "perseverance"),
            Quote(text: "The way to get started is to quit talking and begin doing.", author: "Walt Disney", category: "action"),
            Quote(text: "If life were predictable it would cease to be life, and be without flavor.", author: "Eleanor Roosevelt", category: "uncertainty"),
            Quote(text: "The whole secret of a successful life is to find out what is one's destiny to do, and then do it.", author: "Henry Ford", category: "destiny"),
            Quote(text: "In order to write about life first you must live it.", author: "Ernest Hemingway", category: "experience"),
            Quote(text: "The greatest glory in living lies not in never falling, but in rising every time we fall.", author: "Nelson Mandela", category: "resilience"),
            Quote(text: "Life is really simple, but we insist on making it complicated.", author: "Confucius", category: "simplicity"),
            Quote(text: "May you live every day of your life.", author: "Jonathan Swift", category: "presence"),
            Quote(text: "Life itself is the most wonderful fairy tale.", author: "Hans Christian Andersen", category: "wonder"),
            Quote(text: "Do not let making a living prevent you from making a life.", author: "John Wooden", category: "balance"),
            Quote(text: "Life is not a problem to be solved, but a reality to be experienced.", author: "Søren Kierkegaard", category: "experience"),
            Quote(text: "The unexamined life is not worth living.", author: "Socrates", category: "reflection"),
            Quote(text: "Turn your wounds into wisdom.", author: "Oprah Winfrey", category: "growth"),
            Quote(text: "The way I see it, if you want the rainbow, you gotta put up with the rain.", author: "Dolly Parton", category: "optimism"),
            Quote(text: "Do all the good you can, for all the people you can, in all the ways you can, as long as you can.", author: "John Wesley", category: "service"),
            Quote(text: "Don't be pushed around by the fears in your mind. Be led by the dreams in your heart.", author: "Roy T. Bennett", category: "courage"),
            Quote(text: "You are enough just as you are.", author: "Meghan Markle", category: "self_worth"),
            Quote(text: "Do what you can, with what you have, where you are.", author: "Theodore Roosevelt", category: "action"),
            Quote(text: "It always seems impossible until it's done.", author: "Nelson Mandela", category: "possibility"),
            Quote(text: "Keep your face always toward the sunshine—and shadows will fall behind you.", author: "Walt Whitman", category: "optimism"),
            Quote(text: "You have within you right now, everything you need to deal with whatever the world can throw at you.", author: "Brian Tracy", category: "inner_strength"),
            Quote(text: "What you get by achieving your goals is not as important as what you become by achieving your goals.", author: "Zig Ziglar", category: "growth"),
            Quote(text: "Start where you are. Use what you have. Do what you can.", author: "Arthur Ashe", category: "action"),
            Quote(text: "When I let go of what I am, I become what I might be.", author: "Lao Tzu", category: "transformation"),
            Quote(text: "The energy of the mind is the essence of life.", author: "Aristotle", category: "vitality"),
            Quote(text: "Life shrinks or expands in proportion to one's courage.", author: "Anaïs Nin", category: "courage"),
            Quote(text: "Nothing is impossible. The word itself says 'I'm possible!'", author: "Audrey Hepburn", category: "possibility"),
            Quote(text: "Your limitation—it's only your imagination.", author: "Unknown", category: "potential"),
            Quote(text: "Great things never come from comfort zones.", author: "Unknown", category: "growth"),
            Quote(text: "Dream it. Wish it. Do it.", author: "Unknown", category: "action"),
            Quote(text: "Success doesn't just find you. You have to go out and get it.", author: "Unknown", category: "action"),
            Quote(text: "The harder you work for something, the greater you'll feel when you achieve it.", author: "Unknown", category: "achievement"),
            Quote(text: "Dream bigger. Do bigger.", author: "Unknown", category: "ambition"),
            Quote(text: "Don't stop when you're tired. Stop when you're done.", author: "Unknown", category: "perseverance"),
            Quote(text: "Wake up with determination. Go to bed with satisfaction.", author: "Unknown", category: "daily_practice"),
            Quote(text: "Do something today that your future self will thank you for.", author: "Unknown", category: "future_focus"),
            Quote(text: "Little things make big days.", author: "Unknown", category: "appreciation"),
            Quote(text: "It's going to be hard, but hard does not mean impossible.", author: "Unknown", category: "determination"),
            Quote(text: "Don't wait for opportunity. Create it.", author: "Unknown", category: "proactivity"),
            Quote(text: "Sometimes we're tested not to show our weaknesses, but to discover our strengths.", author: "Unknown", category: "challenges"),
            Quote(text: "The key to success is to focus on goals, not obstacles.", author: "Unknown", category: "focus"),
            Quote(text: "Dream it. Believe it. Build it.", author: "Unknown", category: "creation"),
            Quote(text: "What lies before us and what lies behind us are small matters compared to what lies within us.", author: "Oliver Wendell Holmes", category: "inner_strength"),
            Quote(text: "Peace comes from within. Do not seek it without.", author: "Buddha", category: "inner_peace"),
            Quote(text: "The soul always knows what to do to heal itself. The challenge is to silence the mind.", author: "Caroline Myss", category: "healing"),
            Quote(text: "Gratitude turns what we have into enough.", author: "Aesop", category: "gratitude"),
            Quote(text: "When you arise in the morning, think of what a precious privilege it is to be alive.", author: "Marcus Aurelius", category: "gratitude"),
            Quote(text: "The present moment is filled with joy and happiness. If you are attentive, you will see it.", author: "Thích Nhất Hạnh", category: "mindfulness"),
            Quote(text: "Be happy in the moment, that's enough. Each moment is all we need, not more.", author: "Mother Teresa", category: "presence"),
            Quote(text: "The universe is change; our life is what our thoughts make it.", author: "Marcus Aurelius", category: "mindset"),
            Quote(text: "You have power over your mind - not outside events. Realize this, and you will find strength.", author: "Marcus Aurelius", category: "control"),
            Quote(text: "Very little is needed to make a happy life; it is all within yourself, in your way of thinking.", author: "Marcus Aurelius", category: "happiness"),
            Quote(text: "Dwell on the beauty of life. Watch the stars, and see yourself running with them.", author: "Marcus Aurelius", category: "wonder"),
            Quote(text: "The happiness of your life depends upon the quality of your thoughts.", author: "Marcus Aurelius", category: "mindset"),
            Quote(text: "To live is the rarest thing in the world. Most people exist, that is all.", author: "Oscar Wilde", category: "living_fully"),
            Quote(text: "The only way out is through.", author: "Robert Frost", category: "perseverance"),
            Quote(text: "In three words I can sum up everything I've learned about life: it goes on.", author: "Robert Frost", category: "resilience"),
            Quote(text: "Yesterday is history, tomorrow is a mystery, today is a gift of God, which is why we call it the present.", author: "Bill Keane", category: "presence"),
            Quote(text: "The best and most beautiful things in the world cannot be seen or even touched - they must be felt with the heart.", author: "Helen Keller", category: "love"),
            Quote(text: "Darkness cannot drive out darkness: only light can do that. Hate cannot drive out hate: only love can do that.", author: "Martin Luther King Jr.", category: "love"),
            Quote(text: "If you want to lift yourself up, lift up someone else.", author: "Booker T. Washington", category: "service"),
            Quote(text: "No act of kindness, no matter how small, is ever wasted.", author: "Aesop", category: "kindness"),
            Quote(text: "How wonderful it is that nobody need wait a single moment before starting to improve the world.", author: "Anne Frank", category: "action"),
            Quote(text: "Spread love everywhere you go. Let no one ever come to you without leaving happier.", author: "Mother Teresa", category: "love"),
            Quote(text: "When you have a dream, you've got to grab it and never let go.", author: "Carol Burnett", category: "dreams"),
            Quote(text: "I have learned over the years that when one's mind is made up, this diminishes fear.", author: "Rosa Parks", category: "courage"),
            Quote(text: "With the new day comes new strength and new thoughts.", author: "Eleanor Roosevelt", category: "renewal"),
            Quote(text: "The question isn't who is going to let me; it's who is going to stop me.", author: "Ayn Rand", category: "determination"),
            Quote(text: "There is nothing impossible to they who will try.", author: "Alexander the Great", category: "possibility"),
            Quote(text: "The bad news is time flies. The good news is you're the pilot.", author: "Michael Altshuler", category: "control"),
            Quote(text: "Life has got all those twists and turns. You've got to hold on tight and off you go.", author: "Nicole Kidman", category: "adventure"),
            Quote(text: "Keep your eyes on the stars, and your feet on the ground.", author: "Theodore Roosevelt", category: "balance"),
            Quote(text: "You can waste your lives drawing lines. Or you can live your life crossing them.", author: "Shonda Rhimes", category: "boundaries"),
            Quote(text: "You are never too old to set another goal or to dream a new dream.", author: "Malala Yousafzai", category: "possibility")
        ]
    }
}

// Comprehensive library of 150+ values with definitions
struct ValuesLibrary {
    static let allValues: [Value] = [
        Value(name: "Accountability", definition: "Taking responsibility for your actions and their consequences; being answerable to others and yourself for commitments made."),
        Value(name: "Achievement", definition: "Striving to accomplish goals and reach milestones; finding satisfaction in tangible results and success."),
        Value(name: "Adaptability", definition: "Being flexible and open to change; adjusting effectively to new circumstances and challenges."),
        Value(name: "Adventure", definition: "Seeking new experiences and embracing the unknown; finding excitement in exploration and discovery."),
        Value(name: "Ambition", definition: "Having strong desire and determination to achieve something; setting high goals and working toward them."),
        Value(name: "Authenticity", definition: "Being genuine and true to yourself; expressing your real thoughts, feelings, and values rather than conforming."),
        Value(name: "Autonomy", definition: "Having independence and self-direction; making your own choices and controlling your own life."),
        Value(name: "Balance", definition: "Maintaining equilibrium between different aspects of life; avoiding extremes and finding harmony."),
        Value(name: "Beauty", definition: "Appreciating and creating aesthetic experiences; valuing visual, artistic, or natural elegance."),
        Value(name: "Belonging", definition: "Feeling connected and accepted within a community or group; having meaningful relationships and social bonds."),
        Value(name: "Benevolence", definition: "Caring about the welfare of others; acting with kindness and goodwill toward people."),
        Value(name: "Boldness", definition: "Having courage to take risks and stand out; being willing to be different or controversial when necessary."),
        Value(name: "Calmness", definition: "Maintaining inner peace and composure; approaching situations with serenity rather than anxiety."),
        Value(name: "Caring", definition: "Showing concern and compassion for others' wellbeing; being attentive to others' needs and feelings."),
        Value(name: "Challenge", definition: "Seeking difficult tasks that test your abilities; finding motivation in overcoming obstacles."),
        Value(name: "Clarity", definition: "Pursuing clear thinking and communication; removing ambiguity and confusion from situations."),
        Value(name: "Collaboration", definition: "Working cooperatively with others toward shared goals; valuing teamwork and collective effort."),
        Value(name: "Commitment", definition: "Dedicating yourself fully to people, causes, or goals; following through on promises and obligations."),
        Value(name: "Community", definition: "Contributing to and participating in collective groups; valuing social connection and shared identity."),
        Value(name: "Compassion", definition: "Feeling deep sympathy for others' suffering and wanting to alleviate it; combining empathy with action."),
        Value(name: "Competence", definition: "Developing skill and capability in your endeavors; striving for mastery and effectiveness."),
        Value(name: "Competition", definition: "Engaging in contests or rivalries; finding motivation in measuring yourself against others."),
        Value(name: "Confidence", definition: "Believing in your abilities and judgment; approaching challenges with self-assurance."),
        Value(name: "Connection", definition: "Building deep, meaningful relationships; feeling emotionally linked to others."),
        Value(name: "Conscientiousness", definition: "Being thorough, careful, and diligent; taking duties seriously and acting responsibly."),
        Value(name: "Consistency", definition: "Being reliable and predictable in behavior; maintaining steadiness across time and situations."),
        Value(name: "Contentment", definition: "Finding satisfaction with what you have; experiencing peace and acceptance with your current state."),
        Value(name: "Contribution", definition: "Making a positive difference in the world; adding value to others' lives or to society."),
        Value(name: "Courage", definition: "Facing fear, danger, or difficulty with bravery; taking action despite uncertainty or risk."),
        Value(name: "Creativity", definition: "Generating original ideas and novel solutions; expressing imagination and innovation."),
        Value(name: "Curiosity", definition: "Having a strong desire to learn and explore; asking questions and seeking understanding."),
        Value(name: "Dependability", definition: "Being reliable and trustworthy; consistently doing what you say you'll do."),
        Value(name: "Determination", definition: "Persisting despite obstacles; maintaining firmness of purpose and resolve."),
        Value(name: "Dignity", definition: "Treating yourself and others with respect and worth; maintaining self-respect regardless of circumstances."),
        Value(name: "Diligence", definition: "Working carefully and persistently; showing steady, earnest effort in your endeavors."),
        Value(name: "Discipline", definition: "Controlling your impulses and maintaining focus; following through with rules and routines."),
        Value(name: "Discovery", definition: "Finding new knowledge, places, or experiences; enjoying the process of learning and uncovering."),
        Value(name: "Diversity", definition: "Valuing differences in people, ideas, and approaches; embracing variety and inclusion."),
        Value(name: "Efficiency", definition: "Accomplishing tasks with minimal waste of time or resources; optimizing processes and efforts."),
        Value(name: "Empathy", definition: "Understanding and sharing the feelings of others; seeing situations from others' perspectives."),
        Value(name: "Empowerment", definition: "Enabling yourself and others to take control; building confidence and capability in people."),
        Value(name: "Endurance", definition: "Persisting through long-term challenges; having stamina and staying power."),
        Value(name: "Energy", definition: "Bringing vitality and enthusiasm to activities; maintaining high levels of vigor and drive."),
        Value(name: "Enjoyment", definition: "Finding pleasure and fun in experiences; prioritizing activities that bring joy."),
        Value(name: "Enthusiasm", definition: "Showing intense interest and excitement; approaching life with passion and zeal."),
        Value(name: "Equality", definition: "Treating all people as having equal worth and rights; opposing discrimination and hierarchy."),
        Value(name: "Excellence", definition: "Pursuing the highest quality in everything; refusing to settle for mediocre results."),
        Value(name: "Excitement", definition: "Seeking stimulation and thrilling experiences; valuing activities that create arousal and energy."),
        Value(name: "Exploration", definition: "Investigating new territories, ideas, or possibilities; pushing beyond familiar boundaries."),
        Value(name: "Fairness", definition: "Treating people equitably and justly; applying consistent standards without favoritism."),
        Value(name: "Faith", definition: "Having trust and belief in something greater than yourself; maintaining conviction without complete proof."),
        Value(name: "Family", definition: "Prioritizing close relatives and chosen kin; valuing familial bonds and obligations."),
        Value(name: "Fearlessness", definition: "Acting without being paralyzed by fear; confronting intimidating situations directly."),
        Value(name: "Fidelity", definition: "Being faithful and loyal to commitments, people, or principles; maintaining constancy."),
        Value(name: "Flexibility", definition: "Adapting easily to changes; avoiding rigid thinking or behavior patterns."),
        Value(name: "Focus", definition: "Concentrating attention on priorities; avoiding distraction and maintaining clear direction."),
        Value(name: "Forgiveness", definition: "Letting go of resentment and anger; offering pardon to yourself and others."),
        Value(name: "Freedom", definition: "Having liberty to act, think, and choose; being unrestricted by excessive external control."),
        Value(name: "Friendship", definition: "Building and maintaining close personal relationships; valuing companionship and mutual support."),
        Value(name: "Frugality", definition: "Using resources carefully and avoiding waste; living within or below your means."),
        Value(name: "Fun", definition: "Engaging in playful, enjoyable activities; prioritizing lightheartedness and entertainment."),
        Value(name: "Generosity", definition: "Giving freely of your time, resources, or energy; being liberal and openhanded."),
        Value(name: "Gentleness", definition: "Being mild, tender, and kind in manner; avoiding harshness or roughness."),
        Value(name: "Grace", definition: "Moving through life with elegance and dignity; responding to situations with poise."),
        Value(name: "Gratitude", definition: "Feeling and expressing thankfulness; appreciating what you have and what others do."),
        Value(name: "Growth", definition: "Continuously developing and improving yourself; evolving beyond your current state."),
        Value(name: "Happiness", definition: "Pursuing joy and positive emotional states; prioritizing wellbeing and life satisfaction."),
        Value(name: "Harmony", definition: "Seeking peaceful coexistence and compatibility; avoiding conflict and discord."),
        Value(name: "Health", definition: "Maintaining physical, mental, and emotional wellbeing; prioritizing your body's needs."),
        Value(name: "Helpfulness", definition: "Assisting others and being of service; offering aid and support readily."),
        Value(name: "Honesty", definition: "Telling the truth and being straightforward; refusing to deceive or mislead."),
        Value(name: "Honor", definition: "Acting with integrity and adhering to ethical principles; maintaining reputation and respect."),
        Value(name: "Hope", definition: "Maintaining optimism about the future; believing positive outcomes are possible."),
        Value(name: "Humility", definition: "Being modest and avoiding arrogance; recognizing your limitations and others' contributions."),
        Value(name: "Humor", definition: "Finding and creating amusement; approaching life with levity and the ability to laugh."),
        Value(name: "Independence", definition: "Being self-reliant and not needing others' approval; functioning autonomously."),
        Value(name: "Individuality", definition: "Expressing your unique identity; celebrating what makes you different from others."),
        Value(name: "Innovation", definition: "Creating new methods, ideas, or products; driving change through invention."),
        Value(name: "Inquisitiveness", definition: "Asking questions and seeking deeper understanding; being intellectually curious and probing."),
        Value(name: "Integrity", definition: "Living according to your values consistently; having strong moral principles and honesty."),
        Value(name: "Intelligence", definition: "Valuing mental capability and using reason; pursuing knowledge and understanding."),
        Value(name: "Intimacy", definition: "Building deep emotional closeness with others; sharing vulnerability and authentic connection."),
        Value(name: "Intuition", definition: "Trusting your instincts and inner knowing; making decisions based on gut feelings."),
        Value(name: "Joy", definition: "Experiencing and spreading intense happiness; finding delight in life's moments."),
        Value(name: "Justice", definition: "Ensuring fair treatment and consequences; advocating for what is right and equitable."),
        Value(name: "Kindness", definition: "Being considerate, generous, and friendly; treating others with warmth and care."),
        Value(name: "Knowledge", definition: "Acquiring information and understanding; valuing education and intellectual development."),
        Value(name: "Leadership", definition: "Guiding and inspiring others toward goals; taking responsibility for direction and vision."),
        Value(name: "Learning", definition: "Continuously acquiring new skills and information; remaining a lifelong student."),
        Value(name: "Legacy", definition: "Creating lasting impact beyond your lifetime; building something that endures."),
        Value(name: "Leisure", definition: "Valuing free time and relaxation; making space for rest and recreational activities."),
        Value(name: "Love", definition: "Feeling and expressing deep affection; caring intensely for others' wellbeing and happiness."),
        Value(name: "Loyalty", definition: "Remaining faithful to people, organizations, or causes; standing by commitments through difficulty."),
        Value(name: "Mastery", definition: "Achieving expert-level skill; pursuing excellence and deep competence in areas of focus."),
        Value(name: "Meaning", definition: "Finding purpose and significance in life; ensuring activities align with deeper values."),
        Value(name: "Mindfulness", definition: "Being present and aware in the current moment; paying attention without judgment."),
        Value(name: "Moderation", definition: "Avoiding excess and maintaining reasonable limits; finding the middle path."),
        Value(name: "Modesty", definition: "Being unassuming and humble; avoiding showiness or excessive pride."),
        Value(name: "Open-mindedness", definition: "Considering new ideas and perspectives; avoiding prejudgment and rigid thinking."),
        Value(name: "Openness", definition: "Being transparent and receptive; sharing honestly and welcoming others' input."),
        Value(name: "Optimism", definition: "Maintaining a positive outlook; expecting favorable outcomes and focusing on possibilities."),
        Value(name: "Order", definition: "Creating and maintaining organization; having structure and systematic approaches."),
        Value(name: "Originality", definition: "Being unique and unconventional; creating things that are novel and distinctly yours."),
        Value(name: "Passion", definition: "Feeling intense enthusiasm and emotion; being deeply invested in what matters to you."),
        Value(name: "Patience", definition: "Accepting delays without frustration; maintaining calm and composure while waiting."),
        Value(name: "Peace", definition: "Seeking tranquility and absence of conflict; valuing serenity internally and externally."),
        Value(name: "Perseverance", definition: "Continuing despite difficulty or opposition; refusing to give up on important goals."),
        Value(name: "Playfulness", definition: "Approaching life with spontaneity and fun; not taking everything seriously."),
        Value(name: "Positivity", definition: "Focusing on the good in situations; maintaining an upbeat and constructive attitude."),
        Value(name: "Power", definition: "Having influence and control over outcomes; being able to affect change and make impact."),
        Value(name: "Pragmatism", definition: "Being practical and realistic; focusing on what works rather than ideals alone."),
        Value(name: "Precision", definition: "Being exact and accurate; paying attention to details and avoiding errors."),
        Value(name: "Preparedness", definition: "Planning ahead and being ready; anticipating needs and potential challenges."),
        Value(name: "Presence", definition: "Being fully engaged in the current moment; giving complete attention to what's happening now."),
        Value(name: "Pride", definition: "Taking satisfaction in achievements and identity; maintaining self-respect and dignity."),
        Value(name: "Privacy", definition: "Protecting personal boundaries and information; maintaining control over your private life."),
        Value(name: "Productivity", definition: "Accomplishing tasks efficiently and effectively; generating meaningful output and results."),
        Value(name: "Professionalism", definition: "Maintaining high standards in work; behaving competently and appropriately in professional settings."),
        Value(name: "Prosperity", definition: "Achieving success and flourishing in all areas of life; experiencing abundance and thriving conditions."),
        Value(name: "Purpose", definition: "Having clear direction and meaning; knowing why you do what you do."),
        Value(name: "Quality", definition: "Prioritizing excellence over quantity; ensuring high standards in outputs and experiences."),
        Value(name: "Rationality", definition: "Using logic and reason; making decisions based on evidence and clear thinking."),
        Value(name: "Recognition", definition: "Being acknowledged for your contributions; receiving appreciation and validation from others."),
        Value(name: "Reflection", definition: "Thinking deeply about experiences and yourself; engaging in introspection and contemplation."),
        Value(name: "Reliability", definition: "Being consistently dependable; following through on commitments regularly."),
        Value(name: "Resilience", definition: "Bouncing back from setbacks; recovering quickly from difficulties and adapting."),
        Value(name: "Resourcefulness", definition: "Finding creative solutions with available means; overcoming obstacles through ingenuity."),
        Value(name: "Respect", definition: "Treating others with consideration and regard; honoring people's worth and boundaries."),
        Value(name: "Responsibility", definition: "Being accountable for duties and obligations; taking ownership of your role and actions."),
        Value(name: "Restraint", definition: "Exercising self-control; avoiding impulsive or excessive behavior."),
        Value(name: "Risk-taking", definition: "Willingly exposing yourself to uncertainty; trying things despite potential negative outcomes."),
        Value(name: "Safety", definition: "Protecting yourself and others from harm; prioritizing security and avoiding danger."),
        Value(name: "Security", definition: "Having stability and freedom from threats; maintaining a safe foundation in life."),
        Value(name: "Self-awareness", definition: "Understanding your own thoughts, feelings, and motivations; recognizing your patterns and impact."),
        Value(name: "Self-care", definition: "Attending to your own needs and wellbeing; prioritizing activities that restore and nourish you."),
        Value(name: "Self-control", definition: "Managing impulses and emotions; directing your behavior through willpower."),
        Value(name: "Self-expression", definition: "Communicating your authentic self; sharing your thoughts, feelings, and creativity freely."),
        Value(name: "Self-reliance", definition: "Depending on your own capabilities; being able to function independently."),
        Value(name: "Self-respect", definition: "Valuing and honoring yourself; maintaining dignity and positive self-regard."),
        Value(name: "Service", definition: "Contributing to others' wellbeing; dedicating effort to helping and supporting."),
        Value(name: "Significance", definition: "Making a meaningful impact; being important or influential in some way."),
        Value(name: "Simplicity", definition: "Reducing complexity and excess; focusing on essentials and avoiding complications."),
        Value(name: "Sincerity", definition: "Being genuine and honest in expression; meaning what you say without pretense."),
        Value(name: "Solitude", definition: "Valuing time alone; finding peace and renewal in your own company."),
        Value(name: "Spirituality", definition: "Connecting with something transcendent; exploring meaning beyond the material world."),
        Value(name: "Spontaneity", definition: "Acting on impulse and in the moment; being flexible and unpredictable."),
        Value(name: "Stability", definition: "Maintaining consistency and reliability; avoiding unnecessary change or chaos."),
        Value(name: "Status", definition: "Achieving recognition and social standing; being respected and admired by others."),
        Value(name: "Stewardship", definition: "Taking care of resources and responsibilities entrusted to you; managing with long-term thinking."),
        Value(name: "Strength", definition: "Possessing physical, mental, or emotional power; having capacity to endure and overcome."),
        Value(name: "Structure", definition: "Creating frameworks and systems; organizing life with clear rules and boundaries."),
        Value(name: "Success", definition: "Achieving desired outcomes and goals; reaching milestones others recognize as accomplishments."),
        Value(name: "Support", definition: "Providing help and encouragement to others; being there when people need you."),
        Value(name: "Sustainability", definition: "Acting with long-term viability in mind; ensuring resources and systems can continue."),
        Value(name: "Teamwork", definition: "Collaborating effectively with others; contributing to collective success."),
        Value(name: "Temperance", definition: "Exercising moderation and self-restraint; avoiding excess in all things."),
        Value(name: "Tenacity", definition: "Holding firmly to goals and convictions; refusing to let go despite challenges."),
        Value(name: "Thoughtfulness", definition: "Being considerate and reflective; thinking carefully about impacts and meanings."),
        Value(name: "Thrift", definition: "Using resources economically; getting maximum value while spending minimally."),
        Value(name: "Tradition", definition: "Honoring customs and established practices; maintaining connection to cultural heritage."),
        Value(name: "Tranquility", definition: "Experiencing calm and peace; living without anxiety or turbulence."),
        Value(name: "Transparency", definition: "Being open and clear in communication; operating without hidden agendas."),
        Value(name: "Trust", definition: "Having confidence in others' reliability; believing in integrity and keeping promises."),
        Value(name: "Trustworthiness", definition: "Being worthy of others' confidence; demonstrating reliability and honesty consistently."),
        Value(name: "Truth", definition: "Seeking and speaking what is accurate and real; prioritizing facts over convenience."),
        Value(name: "Understanding", definition: "Comprehending deeply and empathizing; seeing beyond surface to grasp full context."),
        Value(name: "Uniqueness", definition: "Embracing what makes you different; celebrating distinctive qualities and perspectives."),
        Value(name: "Unity", definition: "Creating cohesion and oneness; bringing people or elements together harmoniously."),
        Value(name: "Versatility", definition: "Adapting to various roles and situations; having diverse capabilities and flexibility."),
        Value(name: "Victory", definition: "Achieving wins and overcoming opposition; succeeding in competitive endeavors."),
        Value(name: "Vigor", definition: "Bringing physical and mental energy; approaching life with vitality and intensity."),
        Value(name: "Vision", definition: "Seeing possibilities for the future; having clear, inspiring ideas about what could be."),
        Value(name: "Vitality", definition: "Living with energy and aliveness; feeling vibrant and fully engaged in life."),
        Value(name: "Warmth", definition: "Showing affection and friendliness; creating comfort and positive emotional atmosphere."),
        Value(name: "Wealth", definition: "Having abundant financial resources; accumulating material prosperity."),
        Value(name: "Wisdom", definition: "Applying knowledge with good judgment; understanding deep truths about life and people."),
        Value(name: "Wonder", definition: "Experiencing awe and amazement; maintaining childlike curiosity about the world."),
        Value(name: "Zeal", definition: "Having intense enthusiasm and dedication; pursuing goals with passionate fervor.")
    ]
}
